class Estudante: #definiçao de class
    def __init__(self, matricula, nome, idade, nota): # metedo construtor 
        self.matricula = matricula
        self.nome = nome #atributo
        self.idade = idade
        self.nota = nota

    def hello(self): #método 
        print(f"ola {self.nome}")

# aluno = Estudante (1212, "jao", 18, 80)
# (aluno.nome)

# aluno2 = Estudante(1313, "wendril", 19, 50)
# print(aluno2.nome)

# aluno2.hello()

# aluno2.nome = " vitão vittar "
# aluno2.hello()
    def dados(self): #método 
        print(f"matricula: {self.matricula}")
        print(f"nome: {self.nome}")
        print(f"idade: {self.idade}")
        print(f"nota: {self.nota}")

aluno2 = Estudante(1313, "domitila", 22, 90)

aluno2.dados()