class Professor:
    def __init__(self, nome , idade, escola, materia ):
        self.nome = nome
        self.idade = idade
        self.escola = escola 
        self.materia = materia

    def dados(self): #método 
        print(f"nome: {self.nome}")
        print(f"idade: { self.idade}")
        print(f"escola: {self.escola}")
        print(f"materia: {self. materia}")
     

prof1= Professor("thiago", 22, "senac", "programador")

prof1.dados()