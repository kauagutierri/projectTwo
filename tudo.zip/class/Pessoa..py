# class Pessoa:
#     def __init__(self,nome, idade, endereco= "rua nova veneza, 111"):
#         self.nome = nome 
#         self.idade = idade 
#         self.endereco = endereco

#     def dados(self): #método 
#         print(f"nome: {self.nome}")
#         print(f"idade: { self.idade}")
#         print(f"endereço: {self.endereco}")

#     def mudaridade(self, novaidade):
#         self.idade = novaidade
#         print(self.idade)

# Pessoa1 = Pessoa(" jao", 23)
# Pessoa1.dados()

# Pessoa1.mudaridade(92)
# Pessoa1.dados()
# #####################################################################################################
# class Livro:
#     def __init__(self, nome, autor, editora, paginas):
#         self.nome = nome
#         self.autor = autor
#         self.editora = editora 
#         self.paginas = paginas 

#     def dados(self):
#         print(f"nome: {self.nome}")
#         print(f"autor: {self.autor}")
#         print(f"editora: { self.editora}")
#         print(f"paginas: {self.paginas}")

#     def novaEditora(self, outraEditora):
#         self.editora = outraEditora
#         print(self.editora)

# livro1 = Livro("jao", "vitao", "sei la", "290")
# livro1.dados()

# livro1.novaEditora("Edita nova")
# ###################################################################################
# class Aluno:
#     def __init__(self, nome, ra, n1,n2,n3,n4):
#         self.nome =  nome
#         self.ra = ra
#         self.n1 = n1
#         self.n2 = n2
#         self.n3 = n3
#         self.n4 = n4
#     def dados(self):
#         print (f"{ self.n1 +  self.n2 + self.n3 + self.n4} ")

#     def total(self):
#         media =(self.n1 +  self.n2 + self.n3 + self.n4)/4
        

#         if media > 6:
#             print("aprovado")
#         elif media == 6:
#             print("exame")
#         else:
#             print("reprovado")
# aluno1 = Aluno("wendril", 1212, 6,6,6,6)
# aluno1.dados()
# aluno1.total()
# ##################################################################################################3
# class Banco:
#     def __init__(self, nome,cpf,numero,saldo):
#         self.nome = nome
#         self.cpf = cpf
#         self.numero = numero
#         self.saldo = saldo

#     def depositar(self,quantidade):
#         self.saldo = self.saldo + quantidade
#         print(f"Novo saldo: {self.saldo}")

#     def sacar(self, quantidade):
#         if quantidade > self.saldo:
#             print("Não é possivel sacar mais do que a quantidade na conta")
#         else:
#             if self.saldo > 0:
#                 self.saldo = self.saldo - quantidade
#                 print(f"Novo saldo: {self.saldo}")
#             else:
#                 print("Não ha saldo suficiente para saque")

#     def mostrarsaldo(self):
#         print(f"Saldo da conta: {self.saldo}")
    
# joao = Banco(None, None, None, 200)
# joao.depositar(500)
# joao.sacar(500)
# joao.mostrarsaldo()
# ############################################################################################
# class Funcionario:
#     def __init__(self, nome: str, sobrenome: str, horas_worked: int, valor_hora: int):
#         self.nome = nome
#         self.sobrenome = sobrenome
#         self.horas_worked = horas_worked
#         self.valor_hora = valor_hora

#     def NomeCompleto(self):
#         print(f"{self.nome} {self.sobrenome}")

#     def CalcularSalario(self):
#         print(f"Salario: {self.horas_worked * self.valor_hora}R$")

#     def IncrementarHora(self, hour: int):
#         self.valor_hora = self.valor_hora + hour
#         print("Novo valor por hora:",self.valor_hora)

# funcionario1 = Funcionario("kaua", "gutierrri", 48, 20)
# funcionario1.NomeCompleto()
# funcionario1.CalcularSalario()
# #################################################################################################
# class Circulo:
#     def __init__(self,raio):
#         self.raio=raio
#     def getRaio(self):
#         print(f"O Raio tem o valor de {self.raio}")
#     def getArea(self):
#         areaCirculo=3.14*(self.raio**2)
#         print(f"A área do circulo do raio {self.raio} é {areaCirculo}")
    
#     def getCircunferencia(self):
#         circunferencia=(3.14**2)*self.raio
#         print(f"A circunferência do circulo de raio de {self.raio} é {circunferencia}")

# raio=float(input("Digite o valor do raio: "))
# circulo1=Circulo(raio)
# circulo1.getRaio()
# circulo1.getArea()
# # circulo1.getCircunferencia()
# # ##########################################################################################################
# class Agenda:
#     def __init__(self, dia, mes, ano,anotacao ):
#         self.dia = dia 
#         self.mes = mes
#         self.ano = ano
# #         self.anotacao = anotacao
# #     def dados(self):
# #         if self.ano < 1:
# # #             return False
# # #         if self.mes < 1 or self.mes > 12:
# # #             return False
# # #         if self.dia < 1 or self.mes > 12:
# # #             return False
# # #         if self.mes == 2:
# # #             if self.ano % 4 == 0 and (self.ano % 100 != 0 or self.ano % 400 == 0):
# # #                 if self.dia > 29:
# # #                     return False
# # #             else:
# # #                 if self.dia > 28:
# # #                     return False
# # #         if self.mes in [4, 6, 9, 11] and self.dia > 30:
# # #             return False
# # #         return True

# # #     def anotar_tarefa(self, nova_anotacao):
# # #         self.anotacao = nova_anotacao

# # #     def __str__(self):
# # #         return f"{self.dia}/{self.mes}/{self.ano}: {self.anotacao}"

# # # tarefa1 = Agenda(3, 2, 2024, "Reunião com o time")
# # # if tarefa1.dados():
# # #     print("Data válida")
# # # else:
# # #     print("Data inválida")

# # # print(tarefa1)
# # # ########################################################################################################3
import math

class Triangulo:
    def __init__(self, ladoA, ladoB,ladoC):
        self.ladoA = ladoA
        self.ladoB = ladoB
        self.ladoC = ladoC

    def calculo(self):
        return  self.ladoA + self.ladoB + self.ladoC
    def get_maior_lado(self):
        return max(self.ladoA, self.ladoB, self.ladoC)
    def calcular_area(self):
        semi_perimetro = self.calculo() / 2
        area = math.sqrt(semi_perimetro * (semi_perimetro - self.ladoA) * 
                                           (semi_perimetro - self.ladoB) * 
                                           (semi_perimetro - self.ladoC))
        return area

    def __str__(self):
        return f"Triângulo com lados: A={self.ladoA}, B={self.ladoB}, C={self.ladoC}"
    
ladoA = float(input("Informe o comprimento do lado A do triângulo: "))

ladoB = float(input("Informe o comprimento do lado B do triângulo: "))

ladoC = float(input("Informe o comprimento do lado C do triângulo: "))

triangulo = Triangulo(ladoA, ladoB, ladoC)

print(triangulo)
print(f"Perímetro do triângulo: {triangulo.calculo()}")
print(f"Área do triângulo: {triangulo.calcular_area()}")
print(f"Maior lado do triângulo: {triangulo.get_maior_lado()}")
# # ##############################################################################################################################################################
# # class Aluno_Academia:
# #     def __init__(self, nome, idade, peso, altura, mensalidade=120.0):
# #         self.nome = nome
# #         self.idade = idade
# #         self.peso = peso
# #         self.altura = altura
# #         self.mensalidade = mensalidade

# #     def calcular_IMC(self):
# #         imc = self.peso / (self.altura ** 2)
# #         return imc
# #     def obter_valor_mensalidade(self): 
# #         if self.idade < 18:
# #             return self.mensalidade * 0.5
# #         else:
# #             return self.mensalidade

# #     def __str__(self):

# #         return (f"Nome: {self.nome}\nIdade: {self.idade}\nPeso: {self.peso} kg\n"
# #                 f"Altura: {self.altura} m\nMensalidade: R$ {self.obter_valor_mensalidade():.2f}\n"
# #                 f"IMC: {self.calcular_IMC():.2f}")


# # nome = input("Informe o nome do aluno: ")
# # idade = int(input("Informe a idade do aluno: "))
# # peso = float(input("Informe o peso do aluno (em kg): "))
# # altura = float(input("Informe a altura do aluno (em metros): "))


# # aluno = Aluno_Academia(nome, idade, peso, altura)

# # print(aluno)
# # ######################################################################################################################################################
# class Carro:
#     def __init__(self, modelo, marca, cor, ano, valor, consumo):
#         self.modelo = modelo
#         self.marca = marca
#         self.cor = cor
#         self.ano = ano
#         self.valor = valor
#         self.nivel = 0  
#         self.consumo = consumo 

#     def abastecer(self, litros):
        
#         self.nivel += litros
#         print(f"{litros} litros abastecidos. Nível atual: {self.nivel} litros.")

#     def andar(self, distancia):
       
#         combustivel_necessario = distancia / self.consumo
#         if combustivel_necessario <= self.nivel:
#             self.nivel -= combustivel_necessario
#             print(f"O carro andou {distancia} km. Nível de combustível atual: {self.nivel:.2f} litros.")
#         else:
#             print("Combustível insuficiente para percorrer a distância desejada.")

#     def verificar_nivel(self):
       
#         return self.nivel

#     def calcular_imposto(self):
        
#         ipva = self.valor * 0.025
#         return ipva

#     def __str__(self):
#         return (f"Modelo: {self.modelo}\nMarca: {self.marca}\nCor: {self.cor}\nAno: {self.ano}\n"
#                 f"Valor: R$ {self.valor:.2f}\nNível de combustível: {self.nivel} litros\n"
#                 f"Consumo: {self.consumo} km/L\nIPVA: R$ {self.calcular_imposto():.2f}")

# modelo = input("Informe o modelo do carro: ")
# marca = input("Informe a marca do carro: ")
# cor = input("Informe a cor do carro: ")
# ano = int(input("Informe o ano do carro: "))
# valor = float(input("Informe o valor do carro: "))
# consumo = float(input("Informe o consumo do carro (km/L): "))

# carro = Carro(modelo, marca, cor, ano, valor, consumo)

# print(carro)
# carro.abastecer(50)
# carro.andar(100)
# print(f"Nível de combustível atual: {carro.verificar_nivel():.2f} litros")

# print(f"IPVA do carro: R$ {carro.calcular_imposto():.2f}")
# #########################################################################################################################################
# class NF:
#     def __init__(self, numero, tipo, serie, cnpj, razao_social, data, valor_produtos, icms, frete, ipi):
#         self.numero = numero
#         self.tipo = tipo
#         self.serie = serie
#         self.cnpj = cnpj
#         self.razao_social = razao_social
#         self.data = data
#         self.valor_produtos = valor_produtos
#         self.icms = icms
#         self.frete = frete
#         self.ipi = ipi
#         self.valor_total = 0  
        
#     def obterNumero(self):
#         return self.numero
    
#     def obterDataEmissao(self):
#         return self.data
    
#     def alterarRazaoSocial(self, nova_razao_social):
#         self.razao_social = nova_razao_social
#         print(f"Razão social alterada para: {self.razao_social}")
    
#     def calcularValorTotal(self):
 
#         self.valor_total = self.valor_produtos + self.icms + self.frete + self.ipi
#         print(f"Valor total da NF calculado: R$ {self.valor_total:.2f}")


# nf1 = NF(12345, 'Saída', 1, '12.345.678/0001-00', 'Empresa A', '2024-06-27', 1500.00, 200.00, 50.00, 100.00)


# numero_nf = nf1.obterNumero()
# print(f"Número da NF: {numero_nf}")


# data_emissao_nf = nf1.obterDataEmissao()
# print(f"Data de emissão da NF: {data_emissao_nf}")


# nf1.alterarRazaoSocial("Nova Empresa A")


# nf1.calcularValorTotal()

