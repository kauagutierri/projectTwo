
n1 = int(input("Digite o primeiro número: "))
n2 = int(input("Digite o segundo número: "))
if n1 > n2:
    n1, nu2 = n2, n1
soma = 0
mul = 1
i = n1
while i <= n2:
    if i % 2 == 0:
        soma += i
    else:
        mul *= i
    i += 1
print("A soma dos números pares no intervalo é:", soma)
print("A multiplicação dos números ímpares no intervalo é:", mul)
