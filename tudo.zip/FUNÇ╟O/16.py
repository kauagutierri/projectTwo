
N = int(input("Insira um número inteiro positivo ímpar: "))
if N % 2 == 0 or N <= 0:
    print("Por favor, insira um número inteiro positivo ímpar.")
else:
    for i in range(1, N+1, 2):
        print(i)
