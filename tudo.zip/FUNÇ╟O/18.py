n1= int(input("Digite a quantidade de números 🙄🤐: "))
m = float()
for i in range(n1):
    n = float(input(f"Digite o {i+1}º número: "))
    if n > m:
        m = n
print("O maior número é:", m)
