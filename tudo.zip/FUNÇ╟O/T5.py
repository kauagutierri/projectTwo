num = ['f','e','l','i','c','i','d','a','d','e']
count = 0
while count < len(num):
    print("numero é : ", count, "item da lista: ",num[count])
    count = count +1
