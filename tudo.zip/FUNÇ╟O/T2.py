cidade= []
while len(cidade) < 11:
    cidades= input(" digite a ciade: ")
    cidade.append (cidades)
print(sorted(cidade, reverse=True))