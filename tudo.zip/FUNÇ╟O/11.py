
soma = 0
for i in range(50):
    numero_par = 2 * i
    soma += numero_par
print("A soma dos 50 primeiros números pares é:", soma)
