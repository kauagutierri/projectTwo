nome = []
n1 =int(input("escreva um numero "))
while n1 >= 0:
    print(n1)
    n1 -= 1