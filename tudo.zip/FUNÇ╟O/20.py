
t= 0
p = 0
n = int(input("Digite um número (0 para encerrar): "))
while n != 0:
    t += 1
    if n % 2 == 0:
        p += 1
    n = int(input("Digite um número (0 para encerrar): "))
print("Número de dados lidos:",p)
print("Número de valores pares:",t)
