print("bomdia😁")

nome=[]
while len(nome) < 10:
    valor = int(input("Digite um numero: "))
    if valor > 0:
        nome.append(valor)
print("media",sum(nome)/ len(nome))