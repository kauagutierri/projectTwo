nome = []
n1 = int(input("escreva um numero "))
x = 0
while x  <= n1:
    print(x)
    x += 1
