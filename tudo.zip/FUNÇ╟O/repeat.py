contador = 0
while  (contador < 200):
       print(contador)
       contador = contador +10

x = 0 
soma = 0
while x <= 10:
    soma = soma + x
    print(soma )
#aumeta adiferenca em 1
