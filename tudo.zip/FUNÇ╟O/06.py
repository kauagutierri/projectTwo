nome = []
i = 0
while len(nome) < 10:
    nome.append(int(input(" digite os numeros ")))
print("soma",sum(nome))