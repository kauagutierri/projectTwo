
n = int(input("Insira um número inteiro positivo: "))
while n < 0:
    if n <= 0:
     print("Por favor, insira um número inteiro positivo.")
else:
    soma = (n * (n + 1)) // 2
    print("A soma dos", n, "primeiros números naturais é:", soma)
