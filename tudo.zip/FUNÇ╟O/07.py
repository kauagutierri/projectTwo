nome = []
while len(nome) < 10:
     nome.append(int(input(" digite os numeros ")))
print("media",sum(nome)/ len(nome))