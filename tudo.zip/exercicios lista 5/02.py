def dados(dia, mes, ano):
    meses=["nada", "janeiro","fevereiro", "marco",  "abril", "maio", "junho", "julho","agosto", "setembro","outubro", "novembro ", "dezembro"]
    print(f"{dia} de {meses[mes]} de {ano}")

dia = int(input("digite a dta de hj: "))
mes = int(input("digite o mes: "))
ano = int(input(" digite o ano: "))

dados(dia, mes, ano)