def funcao(base, expoente ):
   res = base ** expoente
   return res 
base = 5
expoente =5
print(f"{base} elevado a {expoente} é {funcao(base, expoente)}")