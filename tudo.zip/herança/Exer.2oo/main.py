from Pessoa1 import Pessoa1
from Professor import Professor

melhorprof = Professor(123,"THIAGO ALMEIDA",32,"Analista de Sistema / Filósofo de Boteco","TODAS",200,25000)

melhorprof.getDados()
print(melhorprof.lecionar())